# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class TimeDisplayAppConfig(AppConfig):
    name = 'time_display_app'
