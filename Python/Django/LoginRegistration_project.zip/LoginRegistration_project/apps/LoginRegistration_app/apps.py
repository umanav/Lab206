# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class LoginregistrationAppConfig(AppConfig):
    name = 'Loginregistration_app'
